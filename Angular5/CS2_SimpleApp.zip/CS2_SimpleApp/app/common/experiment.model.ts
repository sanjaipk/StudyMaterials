export interface Experiment {
  name: string;
  description: string;
  completed: number;
}
