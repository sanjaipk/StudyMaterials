export class Product {
  productId: number;
  productName: string;
  productDescription: string;
price : number;
customerRating:number;
}
